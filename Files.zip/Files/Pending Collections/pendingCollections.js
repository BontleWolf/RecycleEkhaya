/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


  const pendingCollectionsData = [
    {
     pickup_id: "",
      collection_id: "",
      household_user_id: "",
      waste_type: "",
      preferred_date: "",
      pickup_address: "",
      notes: ""},
    {
      pickup_id: "",
      collection_id: "",
      household_user_id: "",
      waste_type: "",
      preferred_date: "",
      pickup_address: "",
      notes: ""
    },
    {
      pickup_id: "",
      collection_id: "",
      household_user_id: "",
      waste_type: "",
      preferred_date: "",
      pickup_address: "",
      notes: ""
    }
  ];

  // To format date
  function formatDate(dateStr) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateStr).toLocaleDateString(undefined, options);
  }

  // Render cards based on waste type filter
  function renderPendingCollections(filterType = "all") {
    const container = document.getElementById("pendingCollectionsContainer");
    if (!container) return;

    let filtered = [...pendingCollectionsData];
    if (filterType !== "all") {
      filtered = filtered.filter(item => item.waste_type === filterType);
    }

    if (filtered.length === 0) {
      container.innerHTML = `<div class="empty-state"><span style="font-size:2rem;">📭</span><p>No pending collections for this waste type.</p></div>`;
      // update badge count
      const badge = document.getElementById("pendingPickupsBadge");
      if(badge) badge.textContent = "0";
      return;
    }

    // update badge with current filtered count (or total pending)
    const totalPending = pendingCollectionsData.length;
    const badgeSpan = document.getElementById("pendingPickupsBadge");
    if(badgeSpan) badgeSpan.textContent = totalPending;

    // Generate each card using all required fields
    const cardsHTML = filtered.map(item => `
      <div class="collection-card" data-waste="${item.waste_type}">
        <div class="card-badge-row">
          <div class="pickup-id-badge"> Pickup: ${item.pickup_id}</div>
          <div class="collection-id">Collection: ${item.collection_id}</div>
          <div class="status-pending">⏳ pending</div>
        </div>
        <div class="card-body">
          <div class="info-row">
            <div class="info-icon">🏠</div>
            <div class="info-text"><strong>Household ID:</strong> ${item.household_user_id}</div>
          </div>
          <div class="info-row">
            <div class="info-icon">🗑️</div>
            <div class="info-text"><strong>Waste type:</strong> <span class="waste-tag">${item.waste_type}</span></div>
          </div>
          <div class="info-row">
            <div class="info-icon">📅</div>
            <div class="info-text"><strong>Preferred date:</strong> ${formatDate(item.preferred_date)}</div>
          </div>
          <div class="info-row">
            <div class="info-icon">📍</div>
            <div class="info-text"><strong>Pickup address:</strong> ${item.pickup_address}</div>
          </div>
          <div class="notes-section">
            <div style="display:flex; gap:6px;"><span>📝</span> <strong>Notes:</strong> ${item.notes || "No additional notes"}</div>
          </div>
        </div>
        <div class="card-footer">
          <button class="btn-reschedule" data-pickupid="${item.pickup_id}">📆 Reschedule / Track</button>
          <button class="btn-delete">🗑️ Delete </button>
          <button class="btn-complete">✅ Completed </button>
        </div>
      </div>
    `).join('');

    container.innerHTML = cardsHTML;

    // attach reschedule listeners (simulate action)
    document.querySelectorAll('.btn-reschedule').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pickupId = btn.getAttribute('data-pickupid');
        alert(`✨ Reschedule flow for pickup ${pickupId}. (Integration with backend: update preferred_date for pending collection.)`);
      });
    });
  }

  // filter change listener
  function initFilters() {
    const filterSelect = document.getElementById("wasteTypeFilter");
    if (filterSelect) {
      filterSelect.addEventListener("change", (e) => {
        renderPendingCollections(e.target.value);
      });
    }
  }

  // Header date and avatar (matching dashboard style)
  function setHeaderDynamic() {
    
    const avatarDiv = document.getElementById("userAvatar");
    if(avatarDiv) avatarDiv.textContent = "LM";
    const greetingSpan = document.getElementById("greetingTime");
    if(greetingSpan) greetingSpan.textContent = "Recyclables";
  }


  // ---- Additionally, demonstrate that clicking "Schedule Pickup" from original dashboard leads to this exact page ----
  // To fully comply: The provided dashboard.html's "Schedule Pickup" link normally points to "/pickups"
  // Also we display "pending recyclable waste" only.

  document.addEventListener("DOMContentLoaded", () => {
    setHeaderDynamic();
    renderPendingCollections("all");
    initFilters();
    attachSidebarEvents();

    // Additional: if there's any URL param to simulate coming from schedule pickup click, we ensure it's active.
    // Also mimic the badge count on sidebar using actual pending data count
    const totalPendingCount = pendingCollectionsData.length;
    const badgeElement = document.getElementById("pendingPickupsBadge");
    if(badgeElement) badgeElement.textContent = totalPendingCount;
  });



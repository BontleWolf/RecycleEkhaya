
    const API_BASE_URL = '/api';
    let allTransactions = [];

    // =============================================
    // DATA RETRIEVAL FROM pickup_tbl DATABASE TABLE
    // Fields: collection_id, collection_date, weight, waste_type, total_amount
    // =============================================
    
    document.addEventListener('DOMContentLoaded', () => {
        loadTransactionsFromPickupTable();
        setupEventListeners();
        updateHeaderDate();
    });

    /**
     * Main function to load transaction data from pickup_tbl
     * Only retrieves records where status = 'COMPLETED' or equivalent
     */
    async function loadTransactionsFromPickupTable() {
        try {
            showLoading();
            
            // Fetch completed collections from pickup_tbl
            // Endpoint should return records where status = 'COMPLETED' or 'COLLECTED'
            const response = await fetch(`${API_BASE_URL}/pickups/completed`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Map database fields to expected format
            // pickup_tbl fields: collection_id, collection_date, weight, waste_type, total_amount
            allTransactions = data.map(record => ({
                collection_id: record.collection_id,
                pickup_id:record.pickup_id,
                collection_date: record.collection_date,
                weight: parseFloat(record.weight),
                waste_type: record.waste_type,
                total_amount: parseFloat(record.total_amount)
            }));
            
            displayTransactions(allTransactions);
            updateStats(allTransactions);
            
        } catch (error) {
            console.error('Error loading transactions from pickup_tbl:', error);
            showError('Failed to load transaction data from database. Please try again.');
        }
    }

    /**
     * Alternative: Load with filter parameters
     * Can be called with query parameters for filtering
     */
    async function loadTransactionsWithFilters(wasteType, month) {
        try {
            showLoading();
            
            let url = `${API_BASE_URL}/pickups/completed`;
            const params = new URLSearchParams();
            
            if (wasteType && wasteType !== 'all') {
                params.append('wasteType', wasteType);
            }
            if (month) {
                params.append('month', month);
            }
            
            if (params.toString()) {
                url += `?${params.toString()}`;
            }
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            allTransactions = data.map(record => ({
                collection_id: record.collection_id,
                pickup_id:record.pickup_id,
                collection_date: record.collection_date,
                weight: parseFloat(record.weight),
                waste_type: record.waste_type,
                total_amount: parseFloat(record.total_amount)
            }));
            
            displayTransactions(allTransactions);
            updateStats(allTransactions);
            
        } catch (error) {
            console.error('Error loading filtered transactions:', error);
            showError('Failed to load filtered transactions.');
        }
    }

    function displayTransactions(transactions) {
        const tbody = document.getElementById('transactionsTableBody');
        if (!tbody) return;

        if (!transactions || transactions.length == 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        🗑️ No completed transactions found in pickup_tbl
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = '';
        const template = document.getElementById('transactionRowTemplate');

        transactions.forEach(transaction => {
            const row = template.content.cloneNode(true);
            
            row.querySelector('.collection-id').textContent = transaction.collection_id;
            row.querySelector('.collection-date').textContent = formatDate(transaction.collection_date);
            row.querySelector('.weight').textContent = transaction.weight.toFixed(1);
            
            const wasteBadge = row.querySelector('.waste-badge');
            wasteBadge.textContent = transaction.waste_type;
            const wasteTypeClass = transaction.waste_type.replace('-', '');
            wasteBadge.classList.add(`waste-${wasteTypeClass}`);
            
            row.querySelector('.total-amount').textContent = `R ${transaction.total_amount.toFixed(2)}`;
            
            tbody.appendChild(row);
        });
    }

    

    function filterTransactions() {
        const wasteType = document.getElementById('wasteTypeFilter').value;
        const monthFilter = document.getElementById('monthFilter').value;
        
        let filtered = [...allTransactions];
        
        if (wasteType !== 'all') {
            filtered = filtered.filter(t => t.waste_type === wasteType);
        }
        
        if (monthFilter) {
            filtered = filtered.filter(t => t.collection_date.startsWith(monthFilter));
        }
        
        displayTransactions(filtered);
        updateStats(filtered);
    }

    function resetFilters() {
        document.getElementById('wasteTypeFilter').value = 'all';
        document.getElementById('monthFilter').value = '';
        displayTransactions(allTransactions);
        updateStats(allTransactions);
    }

    function formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    function showLoading() {
        const tbody = document.getElementById('transactionsTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="loading-state">
                        <div class="spinner"></div>
                        Loading transactions from pickup_tbl...
                    </td>
                </tr>
            `;
        }
    }

    function showError(message) {
        const tbody = document.getElementById('transactionsTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        ⚠️ ${message}
                    </td>
                </tr>
            `;
        }
    }

    function updateHeaderDate() {
        const dateSpan = document.getElementById('headerDate');
        if (dateSpan) {
            const today = new Date();
            dateSpan.textContent = today.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }
    }

    function setupEventListeners() {
        const wasteTypeFilter = document.getElementById('wasteTypeFilter');
        if (wasteTypeFilter) {
            wasteTypeFilter.addEventListener('change', filterTransactions);
        }
        
        const monthFilter = document.getElementById('monthFilter');
        if (monthFilter) {
            monthFilter.addEventListener('change', filterTransactions);
        }
        
        const resetBtn = document.getElementById('resetFilters');
        if (resetBtn) {
            resetBtn.addEventListener('click', resetFilters);
        }
        
        const signOutBtn = document.getElementById('signOutBtn');
        if (signOutBtn) {
            signOutBtn.addEventListener('click', () => {
                window.location.href = '/login';
            });
        }
    }

    

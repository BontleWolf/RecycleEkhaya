package com.EkhayaRecycle.EkhayaRecycleApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EkhayaRecycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EkhayaRecycleApplication.class, args);
	}

}

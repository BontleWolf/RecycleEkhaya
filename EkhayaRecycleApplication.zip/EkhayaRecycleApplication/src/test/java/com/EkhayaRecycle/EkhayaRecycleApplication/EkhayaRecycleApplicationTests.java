package com.EkhayaRecycle.EkhayaRecycleApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EkhayaRecycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
